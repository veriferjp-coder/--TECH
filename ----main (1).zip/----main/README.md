# ---
🚀 SWAPKY TECH BOT SWAPKY TECH BOT is a multi-functional WhatsApp automation system built using Node.js and Baileys. It features AI commands, group moderation tools, media downloaders, economy system, and advanced bot utilities for smooth WhatsApp integration.
